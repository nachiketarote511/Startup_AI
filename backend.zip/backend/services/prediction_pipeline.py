import pandas as pd

from services.model_loader import (

    founder_model,
    funding_model,
    market_model,
    growth_model,
    innovation_model,

    health_model,
    investor_model,

    success_model,
    risk_model,

    competition_model

)


def run_prediction_pipeline(data):

    results = {}

    # -------------------------
    # Founder Strength
    # -------------------------

    founder_df = pd.DataFrame([{

        "founder_count":
            data.founder_count,

        "max_founder_experience":
            data.max_founder_experience,

        "female_founder_count":
            data.female_founder_count,

        "iit_founder":
            data.iit_founder,

        "iim_founder":
            data.iim_founder,

        "foreign_university_founder":
            data.foreign_university_founder,

        "patent_count":
            data.patent_count,

        "trademark_count":
            data.trademark_count,

        "dpiit_registered":
            data.dpiit_registered,

        "gst_registered":
            data.gst_registered

    }])

    founder_prediction = founder_model.predict(
        founder_df
    )[0]

    # results[
    #     "founder_strength"
    # ] = int(founder_prediction)

    # -------------------------
    # Funding Strength
    # -------------------------

    funding_df = pd.DataFrame([{

        "total_funding":
            data.total_funding,

        "latest_funding":
            data.latest_funding,

        "funding_round_count":
            data.funding_round_count,

        "investor_count":
            data.investor_count,

        "top_tier_investor_count":
            data.top_tier_investor_count,

        "average_round_size":
            data.average_round_size,

        "valuation":
            data.valuation,

        "burn_rate":
            data.burn_rate,

        "runway_months":
            data.runway_months

    }])

    funding_prediction = funding_model.predict(
        funding_df
    )[0]

    results[
        "funding_strength"
    ] = int(funding_prediction)

    return results